/*
 * Copyright 2014, NICTA
 *
 * This software may be distributed and modified according to the terms of
 * the BSD 2-Clause license. Note that NO WARRANTY is provided.
 * See "LICENSE_BSD2.txt" for details.
 *
 * @TAG(NICTA_BSD)
 */

int f(int a, int b)
{
  return a / b;
}

int g(int a, int b)
{
  return a % b;
}

int h(unsigned int a, int b)
{
  return a / b;
}

char i(char a, char b)
{
  return a / b;
}

